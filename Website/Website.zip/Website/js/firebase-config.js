const firebaseConfig = {
    apiKey: "AIzaSyCqEOeMEFTs9lVKtNMxCWnEufTyb3F8ggU",
    authDomain: "symptocare-9f34d.firebaseapp.com",
    databaseURL: "https://symptocare-9f34d-default-rtdb.firebaseio.com",
    projectId: "symptocare-9f34d",
    storageBucket: "symptocare-9f34d.appspot.com",
    messagingSenderId: "106625206061",
    appId: "1:106625206061:web:c8be88eb3b1b615ca4f5a4",
    measurementId: "G-9C9WV5LFG1"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);